import { StatusBar } from 'expo-status-bar';
import { useEffect, useState } from 'react';
import { Image, StyleSheet, Text, View } from 'react-native';
import axios from 'axios';

export default function App() {
    const [user, setUser] = useState(false);

    useEffect(function(){
        axios.get('https://api.github.com/users/1')
        .then( res => setUser(res.data) )
        .catch( err => console.log(err) );

        //fetch('https://api.github.com/users/1')
        //.then( data => data.json() )
        //.then( user => setUser(user) )
        //.catch( err => console.log(err.message) )
    }, []);

  return (
    <View style={styles.container}>

      { user && (
          <View style={{alignSelf: 'stretch'}}>

            <Image source={{ uri: user.avatar_url }} style={styles.avatar} />

            <View style={styles.textView}>
              <Text style={styles.text}>
                    Username: { user.name }
              </Text>
            </View>

            <View style={styles.textView}>
              <Text style={styles.text}>
                    Locatioin: { user.location }
              </Text>
            </View>

          </View>
      )}

      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#eee',
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatar: {
      width: '100%',
      height: 400,
      marginBottom: 30
  },
  textView: {
      width: '100%',
      marginVertical: 10,
  },
  text: {
      paddingStart: 18,
      color: 'darkcyan',
      fontSize: 18,
      fontWeight: 'bold',
  },
});
